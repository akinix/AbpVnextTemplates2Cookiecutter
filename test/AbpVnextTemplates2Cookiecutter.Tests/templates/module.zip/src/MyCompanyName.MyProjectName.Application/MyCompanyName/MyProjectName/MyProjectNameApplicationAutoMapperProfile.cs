﻿using AutoMapper;

namespace MyCompanyName.MyProjectName
{
    public class MyProjectNameApplicationAutoMapperProfile : Profile
    {
        public MyProjectNameApplicationAutoMapperProfile()
        {
            
        }
    }
}