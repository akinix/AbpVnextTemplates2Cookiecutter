﻿using AutoMapper;

namespace MyCompanyName.MyProjectName
{
    public class MyProjectNameWebAutoMapperProfile : Profile
    {
        public MyProjectNameWebAutoMapperProfile()
        {
            //Create mappings.
        }
    }
}