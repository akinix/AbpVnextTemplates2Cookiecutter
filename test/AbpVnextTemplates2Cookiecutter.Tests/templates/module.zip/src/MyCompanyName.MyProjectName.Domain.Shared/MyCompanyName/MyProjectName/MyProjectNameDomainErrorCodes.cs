﻿namespace MyCompanyName.MyProjectName
{
    public static class MyProjectNameDomainErrorCodes
    {
        //Add your business exception error codes here...
    }
}
