﻿namespace MyCompanyName.MyProjectName
{
    public static class MyProjectNameConsts
    {
        public const string DefaultDbTablePrefix = "MyProjectName";

        public const string DefaultDbSchema = null;
    }
}
