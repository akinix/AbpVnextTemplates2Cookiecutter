﻿using Volo.Abp.DependencyInjection;

namespace MyCompanyName.MyProjectName
{
    public class MyProjectNameTestData : ISingletonDependency
    {
    }
}
