﻿namespace MyCompanyName.MyProjectName.EntityFrameworkCore
{
    public class MyEntityRepository_Tests : MyEntityRepository_Tests<MyProjectNameEntityFrameworkCoreTestModule>
    {

    }
}
