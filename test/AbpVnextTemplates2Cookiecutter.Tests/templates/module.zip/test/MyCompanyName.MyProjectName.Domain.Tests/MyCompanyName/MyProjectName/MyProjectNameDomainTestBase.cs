﻿namespace MyCompanyName.MyProjectName
{
    public abstract class MyProjectNameDomainTestBase : MyProjectNameTestBase<MyProjectNameDomainTestModule>
    {

    }
}