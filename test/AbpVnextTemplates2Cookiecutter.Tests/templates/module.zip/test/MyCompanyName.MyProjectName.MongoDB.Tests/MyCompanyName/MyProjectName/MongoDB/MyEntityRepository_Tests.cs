﻿namespace MyCompanyName.MyProjectName.MongoDB
{
    public class MyEntityRepository_Tests : MyEntityRepository_Tests<MyProjectNameMongoDbTestModule>
    {

    }
}
